import { Alert, MenuItem, TextField } from '@mui/material';
import { useTranslation } from 'react-i18next';
import { CopyAdornment } from '@/components/design';
import { NumberedSection, ErrorHelper, CustomQuestionSections, SectionStack } from './primitives';
import { NumberField } from '@/components/NumberField';
import { ToothMap } from '@/components/ToothMap';
import { ChangedTeethNote } from './changeHighlight';
import { useChangedTeeth } from './changeMarks';
import { formatGEL } from '@/utils/pricing';
import { localizeMaterials, useUiLang } from '@/features/lab/labText';
import type { FormConfiguration, MaterialOption, PricingConfig } from '@/types/database';
import {
  validatePrint,
  type PrintAnswers,
  validateMilling,
  type MillingAnswers,
} from './fabTypes';

function MaterialSelect({
  materials,
  value,
  onChange,
  readOnly,
  error,
  label,
  unitLabel,
  showPrices,
}: {
  materials: MaterialOption[];
  value: string;
  onChange: (id: string) => void;
  readOnly?: boolean;
  error?: string;
  label: string;
  unitLabel: string;
  /**
   * The service is priced by these materials (`UNIT_BASED`). A described,
   * fixed or unpriced service may keep old unit prices that are not what the
   * order costs, so it lists the names only.
   */
  showPrices: boolean;
}) {
  // The lab's material names in the reader's language; the value is the id.
  const lang = useUiLang();
  return (
    <TextField
      select
      label={label}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      error={!!error}
      helperText={error}
      InputProps={{ readOnly: !!readOnly }}
      sx={{ maxWidth: 440 }}
      fullWidth
    >
      {localizeMaterials(materials, lang).map((m) => (
        <MenuItem key={m.id} value={m.id}>
          {m.name}
          {showPrices && m.unit_price ? ` — ${formatGEL(m.unit_price)}/${unitLabel}` : ''}
        </MenuItem>
      ))}
    </TextField>
  );
}

export function PrintForm({
  configuration,
  pricing,
  value,
  onChange,
  readOnly,
  showErrors,
  rawValues,
  onRawChange,
  customErrors,
}: {
  /** Only needed for the lab's appended questions; this form has no config-driven sections. */
  configuration: FormConfiguration;
  pricing?: PricingConfig;
  value: PrintAnswers;
  onChange: (next: PrintAnswers) => void;
  readOnly?: boolean;
  showErrors?: boolean;
  rawValues?: Record<string, unknown>;
  onRawChange?: (next: Record<string, unknown>) => void;
  customErrors?: Record<string, string>;
}) {
  const { t } = useTranslation('lab');
  const errors = showErrors ? validatePrint(value) : {};
  const materials = pricing?.materials ?? [];
  const set = (patch: Partial<PrintAnswers>) => onChange({ ...value, ...patch });
  // Sections 1-3 below are fixed, so the lab's questions carry on from 4.
  // The other templates gate their sections on the lab's config and count them
  // as they render; this form has nothing to count.
  const counter = 3;

  if (materials.length === 0) {
    return <Alert severity="warning">{t('fabForm.noMaterials')}</Alert>;
  }

  return (
    <SectionStack>
      <NumberedSection number={1} label={`${t('fabForm.material')} *`}>
        <MaterialSelect
          materials={materials}
          value={value.materialId}
          onChange={(id) => set({ materialId: id })}
          readOnly={readOnly}
          error={errors.materialId}
          label={t('fabForm.material')}
          unitLabel={t('fabForm.unit')}
          showPrices={pricing?.model === 'UNIT_BASED'}
        />
      </NumberedSection>
      <NumberedSection number={2} label={`${t('fabForm.units')} *`}>
        <NumberField
          label={t('fabForm.units')}
          value={value.units ?? undefined}
          onChange={(u) => set({ units: u ?? null })}
          min={1}
          error={!!errors.units}
          helperText={errors.units}
          InputProps={{ readOnly: !!readOnly }}
          sx={{ maxWidth: 200 }}
        />
      </NumberedSection>
      <NumberedSection number={3} label={t('fabForm.notes')}>
        <TextField
          value={value.notes}
          onChange={(e) => set({ notes: e.target.value })}
          multiline
          minRows={2}
          fullWidth
          InputProps={{ readOnly: !!readOnly, endAdornment: readOnly && <CopyAdornment text={value.notes} /> }}
        />
      </NumberedSection>

      {rawValues && onRawChange && (
        <CustomQuestionSections
          configuration={configuration}
          values={rawValues}
          onChange={onRawChange}
          readOnly={readOnly}
          errors={customErrors}
          startNumber={counter}
        />
      )}

    </SectionStack>
  );
}

export function MillingForm({
  configuration,
  pricing,
  value,
  onChange,
  readOnly,
  showErrors,
  rawValues,
  onRawChange,
  customErrors,
}: {
  /** Only needed for the lab's appended questions; this form has no config-driven sections. */
  configuration: FormConfiguration;
  pricing?: PricingConfig;
  value: MillingAnswers;
  onChange: (next: MillingAnswers) => void;
  readOnly?: boolean;
  showErrors?: boolean;
  rawValues?: Record<string, unknown>;
  onRawChange?: (next: Record<string, unknown>) => void;
  customErrors?: Record<string, string>;
}) {
  const { t } = useTranslation('lab');
  const errors = showErrors ? validateMilling(value) : {};
  const materials = pricing?.materials ?? [];
  const set = (patch: Partial<MillingAnswers>) => onChange({ ...value, ...patch });
  const changedTeeth = useChangedTeeth('teeth');
  // Sections 1-3 below are fixed, so the lab's questions carry on from 4.
  // The other templates gate their sections on the lab's config and count them
  // as they render; this form has nothing to count.
  const counter = 3;

  if (materials.length === 0) {
    return <Alert severity="warning">{t('fabForm.noMaterials')}</Alert>;
  }

  return (
    <SectionStack>
      <NumberedSection number={1} label={`${t('fabForm.material')} *`}>
        <MaterialSelect
          materials={materials}
          value={value.materialId}
          onChange={(id) => set({ materialId: id })}
          readOnly={readOnly}
          error={errors.materialId}
          label={t('fabForm.material')}
          unitLabel={t('fabForm.unit')}
          showPrices={pricing?.model === 'UNIT_BASED'}
        />
      </NumberedSection>
      <NumberedSection
        number={2}
        label={`${t('fabForm.teeth')} *`}
        hint={t('fabForm.teethCount', { count: value.teeth.length })}
      >
        <ToothMap
          value={value.teeth}
          onChange={readOnly ? undefined : (teeth) => set({ teeth })}
          readOnly={readOnly}
          changedTeeth={changedTeeth}
        />
        <ChangedTeethNote teeth={changedTeeth} />
        <ErrorHelper>{errors.teeth}</ErrorHelper>
      </NumberedSection>
      <NumberedSection number={3} label={t('fabForm.notes')}>
        <TextField
          value={value.notes}
          onChange={(e) => set({ notes: e.target.value })}
          multiline
          minRows={2}
          fullWidth
          InputProps={{ readOnly: !!readOnly, endAdornment: readOnly && <CopyAdornment text={value.notes} /> }}
        />
      </NumberedSection>

      {rawValues && onRawChange && (
        <CustomQuestionSections
          configuration={configuration}
          values={rawValues}
          onChange={onRawChange}
          readOnly={readOnly}
          errors={customErrors}
          startNumber={counter}
        />
      )}

    </SectionStack>
  );
}
