import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import type { OrderStatus } from '@/types/database';
import { useRealtimeConnected } from './realtimeStatus';

/**
 * The red counts on the sidebar.
 *
 * Every count is derived from live state rather than from a per-user "seen"
 * flag: a badge means *something here is waiting on you*, so it appears the
 * moment the work arrives, is identical on every device you sign in from, and
 * clears itself when you actually deal with the thing — never because you
 * happened to glance at the page once.
 *
 * They are counted with `head: true`, so no rows cross the wire, and refreshed
 * on an interval as well as on window focus: coming back to a tab that has been
 * open all afternoon should not show yesterday's numbers.
 *
 * With the realtime socket up, the row events invalidate these keys the moment
 * something changes (liveQueries.ts), so the poll drops to a slow safety net.
 * When the socket is down the old 60-second poll is what keeps them honest.
 */
const LIVE_REFRESH_MS = 300_000;
const POLL_REFRESH_MS = 60_000;

function useShared() {
  const connected = useRealtimeConnected();
  return {
    staleTime: 30_000,
    refetchInterval: connected ? LIVE_REFRESH_MS : POLL_REFRESH_MS,
    refetchOnWindowFocus: true,
  };
}

/** Statuses where the ball is in the doctor's court. */
const AWAITING_DOCTOR: OrderStatus[] = [
  // The lab asked a question and cannot proceed until it is answered.
  'NEEDS_CLARIFICATION',
  // The lab needs the order changed. Unlike the one above there is no
  // "already answered" subtraction below: the status itself is cleared the
  // moment the doctor saves (0030), so being in it always means outstanding.
  'NEEDS_DOCTOR_INPUT',
  // The lab has handed the case over; only the doctor can close it (0022).
  'SENT_TO_CLINIC',
  'RECEIVED_BY_CLINIC',
];

/** A count-only read: `head` keeps the rows themselves off the wire. */
const orderCount = () => supabase.from('orders').select('id', { count: 'exact', head: true });

/**
 * Orders still sitting in NEEDS_CLARIFICATION whose question has been answered
 * — the doctor has replied and it is the lab's move again (0029).
 *
 * Both sides need this number: the lab as "go and read it", the doctor as the
 * orders to stop nagging about. It clears itself the moment the lab moves the
 * status on, which is why the status filter is part of the query rather than a
 * seen-flag.
 *
 * Counted as (orders with any clarification) − (orders with an open one)
 * because PostgREST cannot express "has an answered row AND no open row" in one
 * filter — and an order that was asked, answered, then asked again has both.
 */
async function answeredClarificationCount(
  scope: { column: 'lab_id' | 'doctor_id'; value: string } | null,
): Promise<number> {
  const build = () => {
    const q = supabase
      .from('orders')
      // `!inner` filters the orders down to those that have clarifications; the
      // count stays a count of orders, not of clarification rows.
      .select('id, order_clarifications!inner(id)', { count: 'exact', head: true })
      .eq('status', 'NEEDS_CLARIFICATION');
    return scope ? q.eq(scope.column, scope.value) : q;
  };

  const [withAny, stillOpen] = await Promise.all([
    build(),
    // Both columns: an edit request closed by a save has `answered_at` null
    // by design, and counting it as open pins the badge on forever.
    build()
      .is('order_clarifications.answered_at', null)
      .is('order_clarifications.resolved_by_edit_at', null),
  ]);
  return Math.max(0, (withAny.count ?? 0) - (stillOpen.count ?? 0));
}

/**
 * Orders whose invoice the doctor has not acknowledged (0035).
 *
 * Not a `head: true` count like its neighbours. PostgREST cannot compare two
 * columns, and a replace deliberately keeps the old acknowledgement (it is
 * what tells "changed" from "attached"), so `is null` alone would miss every
 * replaced invoice. The rows read are only orders that have an invoice, which
 * is a small set, and only two timestamps come back per row.
 */
async function unacknowledgedInvoiceCount(
  scope: { column: 'doctor_id'; value: string } | null,
): Promise<number> {
  const q = supabase
    .from('orders')
    .select('id, invoice_acknowledged_at, order_files!inner(created_at)')
    .eq('order_files.file_source', 'INVOICE');
  const { data, error } = await (scope ? q.eq(scope.column, scope.value) : q);
  if (error) return 0;

  const rows = (data ?? []) as {
    invoice_acknowledged_at: string | null;
    order_files: { created_at: string }[];
  }[];
  return rows.filter((r) => {
    const created = r.order_files?.[0]?.created_at;
    if (!created) return false;
    return !r.invoice_acknowledged_at || new Date(r.invoice_acknowledged_at) < new Date(created);
  }).length;
}

/** Lab: new arrivals, unreviewed edits, and answers waiting to be read. */
export function useLabNavAlerts(labId: string | undefined) {
  const shared = useShared();
  const { data } = useQuery({
    queryKey: ['nav-alerts', 'lab', labId],
    enabled: !!labId,
    ...shared,
    queryFn: async () => {
      const [arrived, edited, answered] = await Promise.all([
        orderCount().eq('lab_id', labId!).eq('status', 'SUBMITTED'),
        orderCount().eq('lab_id', labId!).eq('has_unreviewed_edits', true),
        answeredClarificationCount({ column: 'lab_id', value: labId! }),
      ]);
      return {
        orders: arrived.count ?? 0,
        editedOrders: edited.count ?? 0,
        answeredClarifications: answered,
      };
    },
  });
  return data ?? { orders: 0, editedOrders: 0, answeredClarifications: 0 };
}

/** Doctor: their own orders that are waiting on them. */
export function useDoctorNavAlerts(doctorId: string | undefined) {
  const shared = useShared();
  const { data } = useQuery({
    queryKey: ['nav-alerts', 'doctor', doctorId],
    enabled: !!doctorId,
    ...shared,
    queryFn: async () => {
      const [waiting, answered, invoices] = await Promise.all([
        orderCount().eq('doctor_id', doctorId!).in('status', AWAITING_DOCTOR),
        answeredClarificationCount({ column: 'doctor_id', value: doctorId! }),
        unacknowledgedInvoiceCount({ column: 'doctor_id', value: doctorId! }),
      ]);
      // An order the doctor has already answered still sits in
      // NEEDS_CLARIFICATION until the lab moves it — don't keep nagging about
      // work that is no longer theirs.
      //
      // The invoice count is added rather than merged: an order can be waiting
      // on the doctor for a clarification *and* carry an unseen invoice, and
      // both are things to go and do.
      return {
        orders: Math.max(0, (waiting.count ?? 0) - answered) + invoices,
        invoices,
      };
    },
  });
  return data ?? { orders: 0, invoices: 0 };
}

/**
 * Clinic: the same waiting-on-a-doctor orders, across every doctor under the
 * clinic. RLS already limits the read to those doctors, so there is no filter.
 */
export function useClinicNavAlerts(clinicId: string | undefined) {
  const shared = useShared();
  const { data } = useQuery({
    queryKey: ['nav-alerts', 'clinic', clinicId],
    enabled: !!clinicId,
    ...shared,
    queryFn: async () => {
      const [waiting, answered, invoices] = await Promise.all([
        orderCount().in('status', AWAITING_DOCTOR),
        answeredClarificationCount(null),
        unacknowledgedInvoiceCount(null),
      ]);
      return {
        orders: Math.max(0, (waiting.count ?? 0) - answered) + invoices,
        invoices,
      };
    },
  });
  return data ?? { orders: 0, invoices: 0 };
}

/**
 * Platform admin: labs sitting in the approval queue, and reviews a lab has
 * reported and nobody has moderated yet (0044 — a badge, not a notification,
 * J6).
 */
export function useAdminNavAlerts() {
  const shared = useShared();
  const { data } = useQuery({
    queryKey: ['nav-alerts', 'admin'],
    ...shared,
    queryFn: async () => {
      const [labs, reports] = await Promise.all([
        supabase
          .from('labs')
          .select('id', { count: 'exact', head: true })
          .eq('approval_status', 'PENDING_APPROVAL'),
        supabase
          .from('lab_review_reports')
          .select('id', { count: 'exact', head: true })
          .is('resolved_at', null),
      ]);
      return {
        labs: labs.error ? 0 : (labs.count ?? 0),
        reviews: reports.error ? 0 : (reports.count ?? 0),
      };
    },
  });
  return data ?? { labs: 0, reviews: 0 };
}
