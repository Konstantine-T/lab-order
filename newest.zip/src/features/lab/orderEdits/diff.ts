import type { OrderEditSnapshot, OrderRow } from '@/types/database';

/**
 * Who the order is for, at one point in its edit history.
 *
 * `name` is null when the patient row could not be read (an embed that came
 * back empty, or a snapshot taken before the row existed). That is "unknown",
 * not "no name", and the diff must not read it as a change.
 */
export type EditPatient = {
  id: string | null;
  name: string | null;
  dateOfBirth: string | null;
};

// Normalized view of an order's editable fields. We diff two of these — a
// "before" (older) and an "after" (newer) — to decide what the edit changed.
export type EditState = {
  /** null when this side's patient could not be read (see `noPatient` for a
   *  purchase that has none). */
  patient: EditPatient | null;
  /**
   * A buying lab's free-text case reference (0048), which may stand in for a
   * patient. `undefined` when this side does not record one at all (a
   * snapshot written without the key), which the diff reads as "unknown",
   * never as a change.
   */
  patientReference?: string | null;
  /**
   * Known to carry no patient at all: a buying lab's purchase placed or
   * edited "without a patient" (0048). Not the same as `patient: null`, which
   * means the patient could not be read and never counts as a change.
   */
  noPatient?: boolean;
  workLocationDisplay: string;
  invoiceRecipientType: string;
  answers: Record<string, unknown>;
};

// Which discrete fields differ between before/after. The dental answers are
// treated as one block (whole-block diff).
export type EditDiff = {
  patient: boolean;
  workLocation: boolean;
  invoiceRecipient: boolean;
  answers: boolean;
};

/**
 * The `patient` object edit_order writes into every snapshot (0009 onwards,
 * 0031 at runtime; OrderEditSnapshot.patient). Read field by field as unknown,
 * since snapshot_json is whatever the RPC stored at the time.
 */
type SnapshotPatient = {
  id?: unknown;
  first_name?: unknown;
  last_name?: unknown;
  date_of_birth?: unknown;
};

/** The `patients(first_name, last_name, date_of_birth)` embed on a live order. */
export type LivePatientEmbed = {
  first_name: string | null;
  last_name: string | null;
  date_of_birth: string | null;
};

// Stable stringify (sorted keys) so answer maps compare equal regardless of
// key order coming back from Postgres vs. the client.
function stableStringify(value: unknown): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  const obj = value as Record<string, unknown>;
  const keys = Object.keys(obj).sort();
  return `{${keys.map((k) => `${JSON.stringify(k)}:${stableStringify(obj[k])}`).join(',')}}`;
}

export function deepEqual(a: unknown, b: unknown): boolean {
  return stableStringify(a) === stableStringify(b);
}

// Single comparator shared by the section-level answers diff (here) and the
// per-question diff in OrderAnswersDiff, so the two can never disagree about
// whether a value changed.
export function valuesEqual(a: unknown, b: unknown): boolean {
  return deepEqual(a, b);
}

function workLocationDisplay(snap: Record<string, unknown> | null | undefined): string {
  if (!snap) return '';
  const clinic = (snap.clinic_name as string) ?? '';
  const branch = (snap.branch_name as string) ?? '';
  const city = (snap.city as string) ?? '';
  return [clinic, branch].filter(Boolean).join(' · ') + (city ? ` — ${city}` : '');
}

const str = (v: unknown): string | null =>
  typeof v === 'string' && v.trim() !== '' ? v.trim() : null;

/** "First Last", the way the lab's order lists print it. */
export function patientFullName(
  first: string | null | undefined,
  last: string | null | undefined,
): string {
  return [first?.trim(), last?.trim()].filter(Boolean).join(' ');
}

/** Name plus date of birth, so two same-named patients read differently. */
export function patientDisplay(p: EditPatient | null): string {
  if (!p || p.name === null) return '';
  return p.dateOfBirth ? `${p.name} · ${p.dateOfBirth}` : p.name;
}

/** The patient, else the purchase's case reference (0048), else ''. With
 *  both, the reference follows the patient so a change to either shows. */
export function patientOrReference(state: EditState): string {
  const patient = patientDisplay(state.patient);
  const ref = state.patientReference ?? '';
  return patient && ref ? `${patient} · ${ref}` : patient || ref;
}

function patientFromSnapshot(raw: unknown): EditPatient | null {
  if (!raw || typeof raw !== 'object') return null;
  const p = raw as SnapshotPatient;
  const first = str(p.first_name);
  const last = str(p.last_name);
  return {
    id: str(p.id),
    name: first || last ? patientFullName(first, last) : null,
    dateOfBirth: str(p.date_of_birth),
  };
}

export function stateFromSnapshot(s: OrderEditSnapshot): EditState {
  // Read defensively: snapshots taken before 0048 have no such key.
  const raw = s as OrderEditSnapshot & { patient_reference?: unknown };
  // edit_order writes the `patient_reference` key only into a purchase's
  // snapshot (0048), and reads the patient as the definer, so on such a
  // snapshot a null patient is "no patient", not "could not be read".
  const isPurchaseSnapshot = 'patient_reference' in raw;
  const patient = patientFromSnapshot(s.patient);
  return {
    patient,
    patientReference: isPurchaseSnapshot ? str(raw.patient_reference) : undefined,
    noPatient: isPurchaseSnapshot && patient === null,
    workLocationDisplay: workLocationDisplay(s.work_location_snapshot),
    invoiceRecipientType: s.invoice_recipient_type,
    answers: s.answers ?? {},
  };
}

// Live state = current order + answers. The patient comes from the order's
// `patients(...)` embed; without one (not selected, or it came back null) the
// id is still known from the order itself, but the name is not.
export function stateFromLive(
  order: OrderRow & { patients?: LivePatientEmbed | null },
  answersMap: Record<string, unknown>,
): EditState {
  const embed = order.patients ?? null;
  const first = str(embed?.first_name);
  const last = str(embed?.last_name);
  return {
    patient: {
      id: order.patient_id ?? null,
      name: first || last ? patientFullName(first, last) : null,
      dateOfBirth: str(embed?.date_of_birth),
    },
    patientReference: order.patient_reference === undefined ? undefined : str(order.patient_reference),
    // patient_id may be null only on a purchase (0048's CHECK); undefined
    // means the column was not selected, which says nothing.
    noPatient: order.patient_id === null,
    workLocationDisplay: workLocationDisplay(order.work_location_snapshot),
    invoiceRecipientType: order.invoice_recipient_type,
    answers: answersMap,
  };
}

/**
 * Did the edit put the order on a different patient?
 *
 * By id first: edit_order can reassign the order to another patient row, and
 * two patients may share a name (the force_new case in 0031), so name alone
 * would miss exactly the switch that matters. Then by name and date of birth.
 *
 * A side that could not be read never counts as a change, or a missing embed
 * would flag every edit as "patient changed".
 */
export function patientChanged(before: EditPatient | null, after: EditPatient | null): boolean {
  if (!before || !after) return false;
  if (before.id && after.id && before.id !== after.id) return true;
  if (before.name === null || after.name === null) return false;
  return before.name !== after.name || before.dateOfBirth !== after.dateOfBirth;
}

/** A patient that is there: known by id or by name. */
const hasPatient = (state: EditState): boolean =>
  !state.noPatient && !!state.patient && (state.patient.id !== null || state.patient.name !== null);

/** A purchase gained or lost its patient (0048): one side is known to have
 *  none and the other has one. An unreadable side is still never a change. */
function patientPresenceChanged(before: EditState, after: EditState): boolean {
  return (!!before.noPatient && hasPatient(after)) || (!!after.noPatient && hasPatient(before));
}

/** Both sides record a reference and they differ. */
function referenceChanged(before: EditState, after: EditState): boolean {
  if (before.patientReference === undefined || after.patientReference === undefined) return false;
  return before.patientReference !== after.patientReference;
}

export function diffStates(before: EditState, after: EditState): EditDiff {
  return {
    patient:
      patientChanged(before.patient, after.patient) ||
      patientPresenceChanged(before, after) ||
      referenceChanged(before, after),
    workLocation: before.workLocationDisplay !== after.workLocationDisplay,
    invoiceRecipient: before.invoiceRecipientType !== after.invoiceRecipientType,
    answers: !valuesEqual(before.answers, after.answers),
  };
}
