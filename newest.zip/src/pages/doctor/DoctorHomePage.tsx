import { useMemo } from 'react';
import { Box, Button, Stack, Typography } from '@mui/material';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import dayjs from 'dayjs';
import { useAuth } from '@/auth/AuthProvider';
import { supabase } from '@/lib/supabase';
import { ClinicInvitesCard } from '@/features/clinic/ClinicInvitesCard';
import { OrderStatusChip } from '@/components/OrderStatusChip';
import {
  Callout,
  CardStack,
  Icon,
  InitialsAvatar,
  PageHeader,
  SectionCard,
  StatCard,
  StatGrid,
} from '@/components/design';
import { formatGEL } from '@/utils/pricing';
import type { OrderRow } from '@/types/database';
import {
  type HomePreset,
  matchesHomePreset,
} from '@/features/orders/list/homePresets';

type Row = Pick<
  OrderRow,
  | 'id'
  | 'order_code'
  | 'status'
  | 'payment_status'
  | 'final_total'
  | 'generated_total'
  | 'requested_due_date'
  | 'confirmed_due_date'
> & {
  patients: { first_name: string; last_name: string } | null;
  labs: { public_name: string } | null;
  service_snapshot: { name?: string } | null;
  /** Embedded so "needs action" can tell an unanswered question from one the
   *  doctor has already replied to (0029). */
  order_clarifications: {
    question: string;
    answered_at: string | null;
    resolved_by_edit_at: string | null;
    needs_edit: boolean;
  }[];
};

/**
 * Is this order still waiting on the doctor?
 *
 * An order with no clarification rows at all predates the feature (or the lab
 * set the status by hand elsewhere), so it keeps the old behaviour and counts.
 */
const awaitsDoctorAnswer = (row: Row) =>
  row.order_clarifications.length === 0 ||
  row.order_clarifications.some((c) => c.answered_at === null && c.resolved_by_edit_at === null);

/** The lab's note on the still-open change request, if it left one. */
const openEditNote = (row: Row): string | undefined =>
  row.order_clarifications.find(
    (c) => c.needs_edit && c.answered_at === null && c.resolved_by_edit_at === null,
  )?.question;

/**
 * The doctor's landing screen, built to the dashboard mockup: a greeting, four
 * metrics and a "due soon" list, with anything needing attention called out.
 */
export function DoctorHomePage() {
  const { t } = useTranslation('doctor');
  const { t: tc } = useTranslation('common');
  const { user } = useAuth();
  const navigate = useNavigate();
  const doctorId = user?.doctor_profile?.id;

  const { data: orders = [] } = useQuery({
    queryKey: ['doctor-home-orders', doctorId],
    enabled: !!doctorId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('orders')
        .select(
          'id, order_code, status, payment_status, final_total, generated_total, requested_due_date, confirmed_due_date, requested_due_time, confirmed_due_time, service_snapshot, ' +
            'patients(first_name, last_name), labs(public_name), ' +
            'order_clarifications(question, answered_at, resolved_by_edit_at, needs_edit)',
        )
        .eq('doctor_id', doctorId!)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Row[];
    },
  });

  // The squares count with the presets their clicks apply on the orders list
  // (homePresets), so the number is the number of rows they open onto.
  const stats = useMemo(() => {
    const now = dayjs();
    const submitted = orders.filter((o) => matchesHomePreset(o, 'submitted', now));
    const open = orders.filter((o) => matchesHomePreset(o, 'open', now));
    const dueThisWeek = orders.filter((o) => matchesHomePreset(o, 'dueThisWeek', now));
    const needsAction = orders.filter(
      (o) =>
        o.status === 'TRY_IN_PHASE' ||
        (o.status === 'NEEDS_CLARIFICATION' && awaitsDoctorAnswer(o)),
    );
    // Its own list, not a line in `needsAction`: this one names a change the
    // lab is blocked on, so the doctor has to see the request itself, not a
    // count that sends them hunting through the order list.
    const needsChange = orders.filter((o) => o.status === 'NEEDS_DOCTOR_INPUT');
    const unpaid = orders
      .filter((o) => o.payment_status !== 'PAID' && o.status !== 'CANCELLED')
      .reduce((sum, o) => sum + (o.final_total ?? o.generated_total ?? 0), 0);
    return { submitted, open, dueThisWeek, needsAction, needsChange, unpaid };
  }, [orders]);

  const openPreset = (preset: HomePreset) => navigate('/doctor/orders', { state: { preset } });
  const showLabel = (label: string, value: number) => tc('statCard.show', { label, value });

  const dueSoon = useMemo(
    () =>
      [...stats.open]
        .filter((o) => (o.confirmed_due_date ?? o.requested_due_date) != null)
        .sort((a, b) =>
          (a.confirmed_due_date ?? a.requested_due_date ?? '').localeCompare(
            b.confirmed_due_date ?? b.requested_due_date ?? '',
          ),
        )
        .slice(0, 5),
    [stats.open],
  );

  return (
    <>
      <PageHeader
        size="h3"
        title={t('home.welcome', {
          name: user ? `${user.first_name} ${user.last_name}` : '',
        })}
        subtitle={dayjs().format('dddd, MMMM D')}
        actions={
          <>
            <Button component={RouterLink} to="/doctor/orders" variant="outlined">
              {t('nav.orders')}
            </Button>
            <Button
              component={RouterLink}
              to="/doctor/marketplace"
              variant="contained"
              endIcon={<Icon name="arrow_forward" size={16} />}
            >
              {t('orders.newOrder')}
            </Button>
          </>
        }
      />

      <CardStack>
        <ClinicInvitesCard />

        <StatGrid>
          {/* A square reading 0 has nothing to open: no onClick. */}
          <StatCard
            dotColor="#F59E0B"
            label={tc('orderStatus.SUBMITTED')}
            value={stats.submitted.length}
            caption={t('home.stats.awaitingLab')}
            onClick={stats.submitted.length > 0 ? () => openPreset('submitted') : undefined}
            ariaLabel={showLabel(tc('orderStatus.SUBMITTED'), stats.submitted.length)}
          />
          <StatCard
            dotColor="#9292FF"
            label={tc('orderStatus.IN_PROGRESS')}
            value={stats.open.length}
            caption={t('home.stats.openCases')}
            onClick={stats.open.length > 0 ? () => openPreset('open') : undefined}
            ariaLabel={showLabel(tc('orderStatus.IN_PROGRESS'), stats.open.length)}
          />
          <StatCard
            dotColor="#DC2626"
            label={t('home.stats.dueThisWeek')}
            value={stats.dueThisWeek.length}
            caption={t('home.stats.acrossLabs')}
            onClick={stats.dueThisWeek.length > 0 ? () => openPreset('dueThisWeek') : undefined}
            ariaLabel={showLabel(t('home.stats.dueThisWeek'), stats.dueThisWeek.length)}
          />
          {/* Not clickable: there is no payments page or payment filter for
              the doctor yet. */}
          <StatCard
            dotColor="#16A34A"
            label={t('home.stats.unpaid')}
            value={formatGEL(stats.unpaid)}
            caption={t('home.stats.unpaidCaption')}
          />
        </StatGrid>

        {stats.needsAction.length > 0 && (
          <Callout
            tone="warning"
            icon="contact_support"
            title={t('home.stats.needsAction', { n: stats.needsAction.length })}
            onClick={() => navigate('/doctor/orders')}
          />
        )}


        {stats.needsChange.length > 0 && (
          <SectionCard
            icon="edit_note"
            accent="warning"
            title={t('home.needsChange.title', { n: stats.needsChange.length })}
            meta={t('home.needsChange.meta')}
            dense
          >
            {stats.needsChange.map((o) => {
              const patient = o.patients
                ? `${o.patients.first_name} ${o.patients.last_name}`
                : '—';
              const note = openEditNote(o);
              return (
                <Stack
                  key={o.id}
                  direction="row"
                  alignItems="center"
                  spacing={1.5}
                  role="button"
                  tabIndex={0}
                  onClick={() => navigate(`/doctor/orders/${o.id}`)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') navigate(`/doctor/orders/${o.id}`);
                  }}
                  sx={{
                    px: 3,
                    py: 1.625,
                    cursor: 'pointer',
                    borderTop: 1,
                    borderColor: 'divider',
                    '&:hover': { bgcolor: 'action.hover' },
                  }}
                >
                  <InitialsAvatar name={patient} size={28} shape="circle" />
                  <Box sx={{ minWidth: 0, flex: 1 }}>
                    <Typography sx={{ fontSize: '0.8125rem', fontWeight: 700 }} noWrap>
                      {o.order_code} · {patient}
                    </Typography>
                    {/* The lab's own words. A generic "needs your input" would
                        send the doctor to the order to find out what. */}
                    <Typography variant="body2" color="text.secondary" noWrap>
                      {note ?? [o.service_snapshot?.name, o.labs?.public_name]
                        .filter(Boolean)
                        .join(' · ')}
                    </Typography>
                  </Box>
                  <Button
                    size="small"
                    variant="contained"
                    onClick={(e) => {
                      e.stopPropagation();
                      navigate(`/doctor/orders/${o.id}/edit`);
                    }}
                  >
                    {t('home.needsChange.cta')}
                  </Button>
                </Stack>
              );
            })}
          </SectionCard>
        )}

        <SectionCard
          icon="event_upcoming"
          title={t('home.dueSoon')}
          actions={
            <Button component={RouterLink} to="/doctor/orders" size="small">
              {t('home.viewAll')}
            </Button>
          }
          dense
        >
          {dueSoon.length === 0 ? (
            <Typography variant="body1" color="text.secondary" sx={{ px: 3, pb: 2.75 }}>
              {t('home.noDueSoon')}
            </Typography>
          ) : (
            dueSoon.map((o) => {
              const due = o.confirmed_due_date ?? o.requested_due_date!;
              const patient = o.patients
                ? `${o.patients.first_name} ${o.patients.last_name}`
                : '—';
              const urgent = dayjs(due).diff(dayjs(), 'day') <= 1;
              return (
                <Stack
                  key={o.id}
                  direction="row"
                  alignItems="center"
                  spacing={1.5}
                  role="button"
                  tabIndex={0}
                  onClick={() => navigate(`/doctor/orders/${o.id}`)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') navigate(`/doctor/orders/${o.id}`);
                  }}
                  sx={{
                    px: 3,
                    py: 1.625,
                    cursor: 'pointer',
                    borderTop: 1,
                    borderColor: 'divider',
                    '&:hover': { bgcolor: 'action.hover' },
                  }}
                >
                  {/* The mockups' date tile: month over day, tinted by urgency. */}
                  <Box
                    sx={{
                      px: 1.125,
                      py: 0.75,
                      borderRadius: '8px',
                      textAlign: 'center',
                      lineHeight: 1.2,
                      fontSize: '0.6875rem',
                      fontWeight: 800,
                      flexShrink: 0,
                      color: urgent ? 'error.main' : 'warning.dark',
                      bgcolor: urgent ? 'rgba(220,38,38,0.10)' : 'rgba(245,158,11,0.12)',
                    }}
                  >
                    {dayjs(due).format('MMM').toUpperCase()}
                    <br />
                    {dayjs(due).format('D')}
                  </Box>
                  <InitialsAvatar name={patient} size={28} shape="circle" />
                  <Box sx={{ minWidth: 0, flex: 1 }}>
                    <Typography sx={{ fontSize: '0.8125rem', fontWeight: 700 }} noWrap>
                      {o.order_code} · {patient}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" noWrap>
                      {[o.service_snapshot?.name, o.labs?.public_name]
                        .filter(Boolean)
                        .join(' · ')}
                    </Typography>
                  </Box>
                  <OrderStatusChip status={o.status} />
                </Stack>
              );
            })
          )}
        </SectionCard>
      </CardStack>
    </>
  );
}
