import { Box, CircularProgress, Stack } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { PageHeader, StatusPill } from '@/components/design';
import { useQuery } from '@tanstack/react-query';
import { useTranslation } from 'react-i18next';
import { appendDueWindow, dueTimeOf } from '@/features/orders/orderDates';
import { pastDate, shortDate } from '@/features/orders/list/listFormat';
import { useAuth } from '@/auth/AuthProvider';
import { supabase } from '@/lib/supabase';
import { OrderStatusChip } from '@/components/OrderStatusChip';
import { formatGEL } from '@/utils/pricing';
import { OrderRowCard } from '@/features/orders/OrderRowCard';
import { LineageBadge } from '@/features/orders/LineageBadge';
import { useParentOrderCodes } from '@/features/orders/useParentOrderCodes';
import { OrdersEmptyState } from '@/features/orders/OrdersEmptyState';
import { FromLabBadge } from '@/features/lab/orders/FromLabBadge';
import { isLabPurchase } from '@/features/lab/orders/labCustomer';
import type { OrderRow } from '@/types/database';

type Row = OrderRow & {
  lab_services: { name: string } | null;
  service_snapshot: { name?: string } | null;
};

export function LabEditedOrdersPage() {
  const { t } = useTranslation('lab');
  const { t: tc } = useTranslation('common');
  const { user } = useAuth();
  const labId = user?.lab?.id;
  const navigate = useNavigate();

  const { data: orders = [], isLoading } = useQuery({
    queryKey: ['lab-edited-orders', labId],
    enabled: !!labId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('orders')
        .select(
          'id, order_code, status, generated_total, final_total, requested_due_date, ' +
            'confirmed_due_date, requested_due_time, confirmed_due_time, ' +
            'created_at, service_snapshot, doctor_snapshot, continues_order_id, ' +
            'has_unreviewed_edits, last_edited_at, edit_count, buyer_lab_id, lab_services(name)',
        )
        // Not left to RLS: from 0048 the owner also reads its own purchases
        // from other labs, and edits it made to those are not this list's.
        .eq('lab_id', labId!)
        .gt('edit_count', 0)
        // Unconfirmed edits float to the top, but every edited order stays in
        // the list permanently.
        .order('has_unreviewed_edits', { ascending: false })
        .order('last_edited_at', { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Row[];
    },
  });

  // Parent order codes for the continuation badges. Resolved from the rows
  // already loaded, with one batched query for any parent this page didn't
  // fetch — never a query per row.
  const parentCodes = useParentOrderCodes(orders);

  return (
    <>
      <PageHeader title={t('editedOrders.title')} subtitle={t('editedOrders.subtitle')} />

      {isLoading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
          <CircularProgress />
        </Box>
      ) : orders.length === 0 ? (
        <OrdersEmptyState icon="difference" title={t('editedOrders.empty')} />
      ) : (
        <Stack spacing={1.25}>
          {orders.map((row) => {
            const ds = row.doctor_snapshot ?? {};
            const doctorName = [ds.first_name, ds.last_name].filter(Boolean).join(' ') || '—';
            const serviceName = row.lab_services?.name ?? row.service_snapshot?.name ?? '';
            const total = row.final_total ?? row.generated_total;
            const dueRaw = row.confirmed_due_date ?? row.requested_due_date;
            const due = dueRaw
              ? appendDueWindow(shortDate(dueRaw, tc), dueTimeOf(row), tc)
              : undefined;
            return (
              <OrderRowCard
                key={row.id}
                lineage={
                  <LineageBadge
                    continuesOrderId={row.continues_order_id}
                    parentCode={parentCodes.get(row.continues_order_id ?? '')}
                  />
                }
                code={row.order_code}
                primary={doctorName}
                secondary={serviceName}
                highlight={row.has_unreviewed_edits}
                flag={
                  row.has_unreviewed_edits || isLabPurchase(row) ? (
                    <>
                      {row.has_unreviewed_edits && (
                        <StatusPill tone="warning">{t('editedOrders.unconfirmedBadge')}</StatusPill>
                      )}
                      {isLabPurchase(row) && <FromLabBadge />}
                    </>
                  ) : undefined
                }
                status={<OrderStatusChip status={row.status} />}
                total={total != null ? formatGEL(total) : '—'}
                createdDate={pastDate(row.created_at, tc)}
                dueDate={due}
                avatarText={doctorName}
                onClick={() => navigate(`/lab/orders/${row.id}`)}
              />
            );
          })}
        </Stack>
      )}
    </>
  );
}
