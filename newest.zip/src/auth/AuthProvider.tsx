import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import type { PropsWithChildren } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import { clearGuestDraft } from '@/features/public/guestDraft';
import type {
  AppUserRow,
  ClinicRow,
  DoctorProfileRow,
  LabRow,
  UserRole,
} from '@/types/database';

export type AppUser = AppUserRow & {
  doctor_profile?: DoctorProfileRow | null;
  lab?: LabRow | null;
  clinic?: ClinicRow | null;
  /**
   * A lab owner's hidden "buying profile" (0048): the doctor_profiles row its
   * orders to other labs are placed through. Kept apart from
   * `doctor_profile` on purpose, so nothing that asks "is this a doctor"
   * lights up for a lab. Null until the lab first opens its marketplace
   * (ensure_lab_buyer_profile creates it).
   */
  buyer_profile?: DoctorProfileRow | null;
};

type AuthContextValue = {
  session: Session | null;
  user: AppUser | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  /**
   * Reload the AppUser. By default the route guards show their spinner while
   * it loads, which unmounts the page. `silent` keeps the current user — and
   * the page — on screen until the new one arrives: for a page that saves one
   * form while another may hold unsaved input (/lab/profile).
   */
  refreshUser: (opts?: { silent?: boolean }) => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

async function loadAppUser(userId: string): Promise<AppUser | null> {
  const { data: userRow, error } = await supabase
    .from('users')
    .select('*')
    .eq('id', userId)
    .maybeSingle();

  if (error) {
    console.error('[Auth] failed to load public.users row:', error);
    return null;
  }
  if (!userRow) {
    console.warn('[Auth] no public.users row for', userId, '— did the auth trigger run?');
    return null;
  }

  const role = (userRow as AppUserRow).role as UserRole;
  let doctor_profile: DoctorProfileRow | null = null;
  let lab: LabRow | null = null;
  let clinic: ClinicRow | null = null;
  let buyer_profile: DoctorProfileRow | null = null;

  if (role === 'DOCTOR') {
    const { data, error: e } = await supabase
      .from('doctor_profiles')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();
    if (e) console.error('[Auth] failed to load doctor_profiles:', e);
    doctor_profile = (data ?? null) as DoctorProfileRow | null;
  } else if (role === 'LAB_MAIN_ADMIN') {
    const { data, error: e } = await supabase
      .from('labs')
      .select('*')
      .eq('owner_user_id', userId)
      .maybeSingle();
    if (e) console.error('[Auth] failed to load labs:', e);
    lab = (data ?? null) as LabRow | null;
    if (lab) {
      // By the lab, never by user_id: a lookup by owner is what the doctor
      // branch does, and this row must not read as a doctor's profile.
      const { data: buyer, error: be } = await supabase
        .from('doctor_profiles')
        .select('*')
        .eq('buyer_lab_id', lab.id)
        .maybeSingle();
      if (be) console.error('[Auth] failed to load the lab buying profile:', be);
      buyer_profile = (buyer ?? null) as DoctorProfileRow | null;
    }
  } else if (role === 'CLINIC_ADMIN') {
    const { data, error: e } = await supabase
      .from('clinics')
      .select('*')
      .eq('owner_user_id', userId)
      .maybeSingle();
    if (e) console.error('[Auth] failed to load clinics:', e);
    clinic = (data ?? null) as ClinicRow | null;
  }

  return { ...(userRow as AppUserRow), doctor_profile, lab, clinic, buyer_profile };
}

export function AuthProvider({ children }: PropsWithChildren) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<AppUser | null>(null);
  const [initialized, setInitialized] = useState(false);
  const [hydrating, setHydrating] = useState(false);
  const lastUserIdRef = useRef<string | null>(null);

  const hydrate = useCallback(
    async (s: Session | null, opts: { force?: boolean; silent?: boolean } = {}): Promise<void> => {
      if (!s) {
        setUser(null);
        lastUserIdRef.current = null;
        return;
      }
      // Skip refetch on token refresh / tab refocus — same user, no need.
      if (!opts.force && lastUserIdRef.current === s.user.id) return;

      // Silent only when the same user is already loaded: a different (or no)
      // user must still hold the guards, as on sign-in.
      const spinner = !(opts.silent && lastUserIdRef.current === s.user.id);
      if (spinner) setHydrating(true);
      try {
        const u = await loadAppUser(s.user.id);
        if (!u) {
          // Session present but no joined user row: broken state. Sign out so
          // we don't bounce between LoginPage and RoleAwareRedirect.
          console.warn('[Auth] Session present but no app user; signing out.');
          lastUserIdRef.current = null;
          setUser(null);
          await supabase.auth.signOut();
          return;
        }
        setUser(u);
        lastUserIdRef.current = s.user.id;
      } catch (e) {
        console.error('[Auth] hydrate failed', e);
        lastUserIdRef.current = null;
        setUser(null);
        await supabase.auth.signOut();
      } finally {
        if (spinner) setHydrating(false);
      }
    },
    [],
  );

  useEffect(() => {
    let mounted = true;

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, newSession) => {
      if (!mounted) return;

      // Recovery session: set session so updateUser works, but don't sign the
      // user into the app — they stay unauthenticated until they set a new password.
      if (event === 'PASSWORD_RECOVERY') {
        setSession(newSession);
        setInitialized(true);
        return;
      }

      setSession(newSession);

      // The guest draft holds a patient's name and date of birth, saved in
      // this browser by whoever built an order before signing in. Signing out
      // is the moment it must go: a shared clinic computer is the normal case,
      // and the next person at the keyboard is not the same doctor.
      if (event === 'SIGNED_OUT') clearGuestDraft();

      // `session` changes here, but `hydrate` — and with it `user` — cannot run
      // until the next tick (see the deadlock note below). Every render in
      // between would otherwise report `loading: false` while `user` still
      // belongs to the previous session, or to nobody at all just after a
      // sign-in. That window is long enough for RoleGuard to read the stale
      // role and bounce a fresh login to /forbidden. Mark the hydration as
      // started now, so the guards hold a spinner instead of deciding on a
      // user that no longer matches the session.
      if (newSession && lastUserIdRef.current !== newSession.user.id) setHydrating(true);

      // Defer DB calls out of this callback to avoid the supabase-js auth
      // lock deadlock — see github.com/supabase/auth-js/issues/762.
      setTimeout(() => {
        if (!mounted) return;
        void hydrate(newSession).then(() => {
          if (mounted) setInitialized(true);
        });
      }, 0);
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [hydrate]);

  const signIn = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
  }, []);

  const signOut = useCallback(async () => {
    // Also on the SIGNED_OUT event above; here as well so the draft is gone
    // even if the sign-out request itself fails on the way to the server.
    clearGuestDraft();
    await supabase.auth.signOut();
  }, []);

  const refreshUser = useCallback(
    async (opts: { silent?: boolean } = {}) => {
      if (session) await hydrate(session, { force: true, silent: opts.silent });
    },
    [session, hydrate],
  );

  const loading = !initialized || hydrating;

  const value = useMemo<AuthContextValue>(
    () => ({ session, user, loading, signIn, signOut, refreshUser }),
    [session, user, loading, signIn, signOut, refreshUser],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
