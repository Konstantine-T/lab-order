# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
npm run dev          # Vite dev server on :5173
npm run build        # tsc -b && vite build  (type errors fail the build)
npm run typecheck    # tsc -b --noEmit
npm run lint         # eslint .
npm run i18n:check   # locale key parity across en/ka/ru
npm run icons:fetch  # rebuild the Material Symbols woff2 subset from scripts/icon-names.txt
```

There is **no test framework and no CI**. Verification = `typecheck` + `lint` + `i18n:check` + clicking through the app.

Known baseline (don't "fix" these unless asked, don't report them as regressions):

- `i18n:check` is **red**. Most entries are false positives — the flat comparator can't model Russian CLDR plurals (`_few`/`_many`). The real gaps are `doctor: orderCreate.review.formAnswers` (ru) and `lab: orderSheet.moveTo` (ka/ru).
- `lint` reports 0 errors, ~40 warnings.
- **The build is stricter than lint**: `noUnusedLocals`/`noUnusedParameters` are hard `tsc` errors but only ESLint warnings, so lint-clean code can still fail `npm run build`.

## Architecture

React 18 + TS + Vite + MUI v5 SPA, deployed static on Vercel. **There is no server layer** — the browser talks to Supabase (Postgres/Auth/Storage) directly under the anon key via the singleton in [src/lib/supabase.ts](src/lib/supabase.ts). The single exception is one Edge Function, [create-order-chat](supabase/functions/create-order-chat/index.ts) (Telegram userbot).

**Therefore: RLS policies + `SECURITY DEFINER` RPCs are the only authorization boundary.** `RoleGuard`, disabled buttons and client-side state machines are UX, not security. Any new privileged operation belongs in an RPC, not in a client `.update()`.

Domain: a multi-tenant B2B marketplace for dental lab orders. Doctors (or a clinic acting for its doctors) pick a lab service, fill a lab-defined clinical form, and submit; labs configure services/forms/pricing and run the order queue; platform admins approve labs. Trilingual en/ka/ru, light/dark, GEL currency.

**Four roles, four route subtrees, code-split per area.** [src/routes.tsx](src/routes.tsx) holds the guards and the eager public pages (landing, auth, the guest marketplace and lab profile); each signed-in area is one lazy chunk — its layout and every page — in [src/routes/](src/routes/)`<area>Routes.tsx` (loaded through `lazyRoute()`), and the guest order wizard is a fifth (`guestOrderRoute.tsx`). A new area page goes in its `*Routes.tsx`, not in `routes.tsx`. Each is `ProtectedRoute` → `RoleGuard` → the area chunk → `*Layout` (which wraps the shared `AppShell`):

| Role | Area | Pages |
|---|---|---|
| `DOCTOR` | `/doctor` | [src/pages/doctor/](src/pages/doctor/) |
| `LAB_MAIN_ADMIN` | `/lab` | [src/pages/lab/](src/pages/lab/) |
| `PLATFORM_ADMIN` | `/admin` | [src/pages/admin/](src/pages/admin/) |
| `CLINIC_ADMIN` | `/clinic` | [src/pages/clinic/](src/pages/clinic/) — reuses the doctor's `MarketplacePage` / `LabPublicProfilePage` / `OrderEditPage` via a `basePath` prop |

Provider tree ([src/main.tsx](src/main.tsx), rendered once the visitor's language bundle is in — `i18nReady`): `ColorModeProvider` → `QueryClientProvider` → `BrowserRouter` → `AuthProvider`. The date pickers' `LocalizationProvider` sits inside each lazy area and the guest wizard instead ([DatePickerProvider.tsx](src/routes/DatePickerProvider.tsx)). `AuthProvider` loads `public.users` plus the role's side row (`doctor_profiles` / `labs` / `clinics`) into one `AppUser`.

**Order lifecycle:** marketplace → `OrderCreateWizard` (autosaves to `order_drafts`, dedups the patient via `find_matching_patient`) → `submit_order` RPC (writes `orders` + `order_answers` + snapshots) → the lab drives status on `LabOrderSheetPage` as far as `SENT_TO_CLINIC` → the **doctor** closes the case (`complete_order` / `reopen_order`). Doctor edits after submit go through `edit_order` and surface to the lab as `has_unreviewed_edits`.

`orders` is the hub and carries denormalized `*_snapshot` JSONB (lab, service, work location, invoice recipient, doctor) captured at submit time. **Read historical data from the snapshot, not the live join.** `lab_form_versions` is immutable — change a form by publishing a new version (`publish_lab_form`), never `UPDATE`.

RPCs the client calls: `submit_order`, `clinic_submit_order`, `edit_order`, `complete_order`, `reopen_order`, `find_matching_patient`, `publish_lab_form`, `get_order_chat`, `get_order_staff`, `clinic_doctors`, `my_clinic_invites`, `respond_clinic_invite`, `clinic_remove_doctor`, `clinic_payables_list`, `clinic_payables_by_doctor`, `lab_receivables_list`, `record_payment`, `lab_finance_lock_state`, `set_lab_finance_passcode`, `verify_lab_finance_passcode`, `reset_lab_finance_passcode`, `admin_feedback_list`, `set_lab_public_translations`, `set_lab_price_list`, `set_lab_service_translations`, `mark_notifications_read`, `cancel_order`, `save_lab_review`, `delete_lab_review`, `reply_to_lab_review`, `report_lab_review`, `moderate_lab_review`, `lab_reviews_public`, `ensure_lab_buyer_profile`.

## Conventions

**Order forms are not RHF/zod.** [src/features/orderForms/](src/features/orderForms/) hand-builds one component per clinical template; `OrderForm.tsx` dispatches on `configuration._templateCode`, falling back to the generic [DynamicForm](src/components/DynamicForm.tsx). Each template ships a triad in its `*Types.ts`: `emptyXAnswers`, `coerceXAnswers(unknown)` (defensive hydration of stored answers), `validateX() → Record<field, message>`. Adding a template = new `xTypes.ts` + `XForm.tsx` + a case in **both** `OrderFormBody` and `isOrderFormValid` in `OrderForm.tsx` + seeding `_templateCode` in [buildDefaultConfig.ts](src/features/lab/forms/buildDefaultConfig.ts) + a `platform_form_templates` seed SQL. Some templates reuse another's form, so wire them by predicate, not by code: `isCnbTemplate()` also matches `TEMPORARY_CROWN`, `TITANIUM_MILLING` and `FINAL_CONSTRUCTION` (C&B plus a design section), and `isImplantTemplate()` covers `CONSTRUCTIONS_ON_IMPLANTS` and `IMPLANT_ABUTMENTS` (`ImplantRestorationForm variant="abutments"`: no crown, no "Already in mouth") — pricing, the lab's `answerSections.ts` and `orderFacts.ts` each need the new one. Answers live in one flat `Record<string, unknown>` shared with appended `custom_question` fields, so keep structured keys distinctive. The lab's edit diff ([OrderAnswersDiff.tsx](src/features/lab/orderEdits/OrderAnswersDiff.tsx)) marks changed sections by matching [answerSections.ts](src/features/lab/orderEdits/answerSections.ts) `labelKey`s against the headings the forms render (`NumberedSection` labels, C&B `ParamRow` labels), so renaming a heading or adding a section means updating `answerSections.ts` too — drift shows as a dev `console.warn('[OrderAnswersDiff] changes no section marked')` and the previous-version accordion opening by itself. Tooth charts additionally ring the individual teeth that changed: [toothChanges.ts](src/features/lab/orderEdits/toothChanges.ts) lists each template's charts by answer path (`toothAssignments`, `upper.implantPositions`, `cnbAnswers.toothAssignments`, …) and the form asks with `useChangedTeeth(path)` → `ToothMap changedTeeth` + `ChangedTeethNote`, so a new tooth chart needs an entry there (no warning fires if one is missing).

**Every other form** (auth, doctor/lab profile, service basics, work locations) uses react-hook-form + zod + `RHFTextField`, which requires a `FormProvider` ancestor. Zod messages are translated through [src/lib/zod-i18n.ts](src/lib/zod-i18n.ts) (`errors` namespace).

**Teeth** are always stored in Universal numbering (1–32). Convert to FDI only for display ([ToothMap.tsx](src/components/ToothMap.tsx)).

**i18n**: every user-visible string is a key. 8 namespaces (`common` is the default, plus `auth`, `doctor`, `lab`, `clinic`, `admin`, `landing`, `errors`) × 3 locales, loaded one language at a time: each locale's eight namespaces are one lazy chunk in [src/i18n/bundles/](src/i18n/bundles/) (a new namespace goes in all three bundles and in `NAMESPACES` in [src/i18n/index.ts](src/i18n/index.ts)). A key must exist in **all three** locales.

**Design system**: import shared UI from [@/components/design](src/components/design/index.ts) (`PageHeader`, `SectionCard`, `StatCard`, `StatusPill`, `DataTable`, `EmptyState`, …). Icons go through `<Icon name="receipt_long" />` — Material Symbols Rounded, self-hosted as a ~55 KB subset; **add the ligature name to [scripts/icon-names.txt](scripts/icon-names.txt) and run `npm run icons:fetch`**, or the glyph renders as literal text. Don't import `@mui/icons-material` in app code. Colors, radii, spacing and layout constants come from [src/theme/tokens.ts](src/theme/tokens.ts) — no ad-hoc hex.

**React Query**: one shared client (staleTime 30s, no refetch-on-focus, retry 1). Array keys scoped by id (`['lab-order', orderId]`); `supabase.from()` / `.rpc()` called directly in `queryFn` / `mutationFn`; invalidate in `onSuccess` — including the *other* role's keys (a doctor edit must invalidate `lab-*` so the lab dashboard refreshes).

**Realtime + notifications** (0043, [src/features/notifications/](src/features/notifications/)): `RealtimeProvider` is mounted only in the signed-in shells (`AppShell` / `TopNavShell`) — guests never open a WebSocket. Row events (INSERT/UPDATE) on the published tables are a *signal to refetch*, never written into the cache; [liveQueries.ts](src/features/notifications/liveQueries.ts) is the single table → query-key map, so **a new page's query key goes there** or it won't follow other users' changes. A form seeded from live data uses `useLiveFormSync` + `LiveUpdateBanner` (see `LabOrderSheetPage` / `OrderEditPage`) so a refetch never overwrites what the user is typing. `public.notifications` rows are written **only by triggers** through `notify()` (kind + raw params, never text, never a patient name) and read through RLS select-own; `mark_notifications_read` is the only client write. A new kind = the CHECK list in 0043 + `NotificationKind` in `database.ts` + the `KINDS` record in `notificationText.ts` + `common:notifications.kinds.*` keys. `orders.placed_by_user_id` is stamped by trigger from `auth.uid()` (clinic-placed vs doctor-placed); it is null on orders placed before 0043. Realtime must also be enabled for the project in the Supabase dashboard; without it the badges fall back to a 60 s poll.

**Pricing** ([src/utils/pricing.ts](src/utils/pricing.ts)) branches by duck-typing the config and answers (`pricingShape()`), so renaming an answer key can silently re-route the math. `calculatePrice` returns `kind: 'CALCULATED' | 'DESCRIBED'` — check `kind` before rendering a number, or a `LAB_DESCRIBED` service will show a confident 0.00.

**Order statuses**: `LAB_SELECTABLE_STATUSES` and `COMPLETABLE_STATUSES` in [src/types/database.ts](src/types/database.ts) are the source of truth (the lab deliberately cannot set `COMPLETED`); [src/features/orders/pipeline.ts](src/features/orders/pipeline.ts) maps the 10 statuses onto the 6 displayed pipeline stages.

**Files**: the `order-files` bucket, path `<lab_id>/<order_id>/<file>` ([orderFilesApi.ts](src/features/orders/orderFiles/orderFilesApi.ts)); service cover images have their own bucket. Never surface a raw Supabase storage error — they are English-only and mention RLS at the user; map to an `OrderFileErrorKind` and translate.

Commit messages follow `type(scope): lowercase summary` (`feat(lab):`, `fix(orders):`, `chore(db):`).

## Database changes

DDL is applied **by hand** — the Supabase dashboard SQL Editor, or `node scripts/apply-sql.mjs <file.sql>` (needs `SUPABASE_ACCESS_TOKEN` in `.env`; the project ref is hardcoded). There is no Supabase CLI dependency, no `config.toml` and no migration runner, so:

- **Write every migration idempotently** (`create or replace`, `if not exists`) — files get replayed.
- The real history is `supabase/migrations/*.sql` (**0007 is absent by design**) *plus* the loose top-level `supabase/*.sql` files; `all-in-one.sql` and `phase4-6.sql` re-bundle earlier migrations. The `SETUP*.md` docs do **not** capture the full apply order.
- **Several functions are redefined in multiple files** and the last one applied wins: `handle_new_user` (0003, 0011), `submit_order` / `_submit_order_impl` (0008, 0010, 0014, 0020, 0031, 0032; `_submit_order_impl` again in 0048), `edit_order` (0009, 0014, 0020, 0031, 0048), `find_matching_patient` (0008, 0020, 0023, 0048), and since 0048 also `_lab_receivables_rows` (0028), `_lab_reviewer_display` / `save_lab_review` (0044), `my_clinic_invites` / `respond_clinic_invite` (0013). Edit the runtime winner and keep the others in sync. In particular `handle_new_user` carries a **signup-role allow-list guard** (only `DOCTOR` / `LAB_MAIN_ADMIN` / `CLINIC_ADMIN` may self-register; `PLATFORM_ADMIN` is granted out-of-band only) that closed a privilege-escalation hole — it must survive every redefinition.
- [src/types/database.ts](src/types/database.ts) is hand-written, never generated; update it alongside schema changes (it has drifted before).
- **Guests read `public.labs` through a column list** (0039), never a table-level grant: RLS limits rows, not columns, and the old `grant select on public.labs to anon` handed every guest each lab's IBAN and tax id. So **a new `labs` column is invisible to signed-out pages** — their select fails with 42501 while signed-in pages work — until it is added to 0039's grant (and the same list in 0034 / `all-in-one.sql`) and 0039 is re-run. Test it signed out.
- **`lab_services.translations`** (0042) holds the lab's en/ru (and accepted ka) copy of a service's name, description and turnaround label; it changes only through `set_lab_service_translations` (trigger `lab_services_translations_via_rpc` refuses direct writes with `translations_rpc_only`). Question, option, material and price-description translations ride inside the form version JSON as `translations` keys. Read text through [labText.ts](src/features/lab/labText.ts) (`pickText`, `fieldText`, `optionLabels`, `localizeMaterials`, `priceDescription`, `useUiLang`) — the reader's language, else the base text; options are translated **by index, for display only**, and stored answers / material ids stay the base values. Guests can read `translations` today only because `lab_services` (unlike `labs`) still has a **table-level** anon `SELECT` — whoever converts it to a 0039-style column list must include `translations`, or the guest catalogue, landing and lab profile break.
- Once a lab leaves review (any status but `PENDING_APPROVAL` / `CHANGES_REQUESTED`), its name, legal, contact and bank columns are locked by trigger (0040, raises `lab_identity_locked`, 42501); admins and `SECURITY DEFINER` RPCs pass. `public_translations` / `price_lists` change only through their RPCs (0037 / 0038 triggers refuse direct writes). Map these errors to translated text ([labProfileErrors.ts](src/features/lab/labProfileErrors.ts)), never show them raw.
- Reviews (0044) are private tables: guests and the public profile read them only through `lab_reviews_public()`, never `lab_reviews` directly. `lab_rating_summary` is maintained by trigger and read-only to clients. The `notifications` kind CHECK list now lives in 0044, so a new notification kind redefines it there, keeping the review kinds.
- A priced order needs `final_price_note` (0046: trigger `orders_final_price_note_guard` raises `final_price_note_required`). 0046 redefines `tg_notify_order_price`; any later redefinition must keep the `note` param.
- **Only the lab (and a platform admin) may write `orders.status` directly** (0045 trigger, raises `status_change_not_allowed`). Doctors and clinic admins change a status only through `SECURITY DEFINER` RPCs (`cancel_order` while `SUBMITTED`, `complete_order`, `reopen_order`, `edit_order`); the same trigger stamps `cancelled_at` / `cancelled_by_user_id` on every cancel. A new doctor-side status change therefore needs an RPC, not a client `.update()`.
- **A lab orders from another lab through a hidden "buying profile"** (0048): a `doctor_profiles` row with `buyer_lab_id` = the lab and `user_id` = its owner, created only by `ensure_lab_buyer_profile()`. So **a lab owner has a `current_doctor_id()`** and the doctor RLS shows it its purchases next to the lab RLS's incoming orders: every lab-side query must filter `.eq('lab_id', labId)`, every purchase query `.eq('doctor_id', buyerProfileId)`. A purchase has `orders.buyer_lab_id` (frozen), recipient `LAB`, an optional patient (`patient_id` null, `patient_reference`), and a `doctor_snapshot` that describes the buying lab (`is_lab: true`). Doctors still need a patient (`patient_required`) and can never pick `LAB` (`invoice_recipient_not_allowed`). Because one user can now be both an order's doctor and a lab's owner, a client may never change `orders.lab_id`, `doctor_id` or `doctor_snapshot` (trigger, `order_parties_read_only`), and `save_lab_review` refuses a review of the caller's own lab; tell a purchase apart by `buyer_lab_id`, never by the snapshot.
- **`labs.logo_url` accepts only this lab's own `lab-logos` bucket path or null** (0047 trigger, `logo_url_not_uploaded`); upload through [labLogo.ts](src/features/lab/logo/labLogo.ts), which saves immediately, outside the profile form.

## Further reading

- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) — deep 9-section brief. Accurate on the core, but written 2026-07-23: it predates clinic finances, lab staff + Telegram chats, order file uploads, the finance passcode lock, nav alert badges and the `components/design` system, and parts of its §8 gotcha list have since been fixed.
- [docs/SPEC-lab-staff-telegram.md](docs/SPEC-lab-staff-telegram.md) (includes the userbot runbook for `scripts/tg-login.mjs`), [docs/SPEC-clinic-doctors.md](docs/SPEC-clinic-doctors.md), [docs/database.md](docs/database.md), [docs/frontend.md](docs/frontend.md), [docs/phases.md](docs/phases.md).
- [SESSION-HANDOFF.md](SESSION-HANDOFF.md) is a stale July snapshot — its "uncommitted work" section has long since been committed.
